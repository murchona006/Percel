package com.lbdl_delivery.merchant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
