class BaseUrl {
  //static const baseUrl = 'http://192.168.0.10/Courierlab_Agent_Wise/api';
  //static const baseUrl = 'http://192.168.0.6/amvines_logistrics/api';
  // static const baseUrl = 'https://system.lbdl.com.bd/api';//'https://system.greenmaxcourier.com/api';
  static const baseUrl = 'http://system.olectraexpress.com/api';



// static const baseUrl = 'http://192.168.0.6/amvines_logistrics/api';
}
